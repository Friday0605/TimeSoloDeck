The application works perfectly with just a minor issue that is that the export feature
does not work on GoogleAPI 29, having said that it works on every other API
versions(API 24 and greater).
        --Team Six